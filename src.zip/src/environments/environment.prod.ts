export const environment={
    production:false,
    firebaseConfig :{
       apiKey: "AIzaSyAFhDQtxH68oG2cjDQpTLritbaijajeSDE",
       authDomain: "studentdata-f8ccd.firebaseapp.com",
       databaseURL: "https://studentdata-f8ccd-default-rtdb.firebaseio.com",
       projectId: "studentdata-f8ccd",
       storageBucket: "studentdata-f8ccd.appspot.com",
       messagingSenderId: "580243536218",
       appId: "1:580243536218:web:d1080bf6ec14a22e8f9b63",
       measurementId: "G-N4SE744TTM",
     },
   
   
   };