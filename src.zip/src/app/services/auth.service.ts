import { Injectable } from '@angular/core';
import { Auth, authState, signInWithEmailAndPassword } from '@angular/fire/auth';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { from } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  currentUser$ = authState(this.auth);
  //Currentuser = authState(this.auth);
  constructor(private auth: Auth, private fireauth: AngularFireAuth, private route: Router) {
    console.log(this.currentUser$)
  }

  login(username: any, password: any) {
    return from(signInWithEmailAndPassword(this.auth, username, password))
  }

  logout() {
    return from(this.auth.signOut())
  }

  Singup(email: any, password: any) {
    return from(createUserWithEmailAndPassword(this.auth, email, password)
      // .then((result) => {
      //   this.sendverificationemail()
      // }).catch((error) => {
      //   window.alert(error)
      // })
    )
  }
  sendverificationemail()
   {
    return this.fireauth.currentUser.then((user) => {
      return user?.sendEmailVerification()
    }).then((result) => {
    })
  }
}
