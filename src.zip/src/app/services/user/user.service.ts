import { AuthenticationService } from '../auth.service';
import { ProfileUser } from 'src/app/_helper/user-profile';
import { Injectable } from '@angular/core';
import { docData, Firestore } from '@angular/fire/firestore';
import { from, Observable, of, switchMap } from 'rxjs';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  get cureentUserProfile(): Observable<ProfileUser | null> {
    return this.authservice.currentUser$.pipe(
      switchMap((user) => {
        if (!user?.uid) {
          return of(null); 
        }
        const ref = doc(this.firestore, 'user', user?.uid);
        return docData(ref) as Observable<ProfileUser>;
      })
    );
  }
  constructor(private firestore: Firestore, private authservice: AuthenticationService) { }
  adduser(user: ProfileUser): Observable<any> {
    const ref = doc(this.firestore, 'user', user?.uid);
    return from(setDoc(ref, user));
  }
  updateUser(user: ProfileUser): Observable<any> {
    const ref = doc(this.firestore, 'user', user?.uid);
    return from(updateDoc(ref, { ...user }));
  }
}
