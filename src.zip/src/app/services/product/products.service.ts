import { Injectable } from '@angular/core';
import { AngularFirestoreCollection, AngularFirestore } from '@angular/fire/compat/firestore';
import { addDoc, collection, deleteDoc, doc, query, where } from 'firebase/firestore';
import { take, concatMap, map, BehaviorSubject, Observable } from 'rxjs';
import { product } from 'src/app/_helper/product-details';
import { cart } from 'src/app/_helper/product-details';
import { AuthenticationService } from '../auth.service';
import { collectionData, Firestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private dbpath = '/products'
  private path = '/cart'
  productref: AngularFirestoreCollection<product>
  cartproduct!: AngularFirestoreCollection<cart>;
  mobilearray: any = [];
  mobilelistsubject = new BehaviorSubject<any>([]);
  constructor(private db: AngularFirestore, private auth: AuthenticationService, private firestore: Firestore) {
    this.productref = db.collection(this.dbpath)
    this.cartproduct = db.collection(this.path)
  }

  getAll(): AngularFirestoreCollection<product> {
    return this.productref
  }

  getcart(): AngularFirestoreCollection<cart> {
    return this.cartproduct
  }

  createbook(product: cart) {
    const ref = collection(this.firestore, 'cart')
    return this.auth.currentUser$.pipe(
      take(1),
      concatMap((user) =>
        addDoc(ref, {
          UserIDS: [user?.uid],
          AddToBook: [
            {
              description: product?.description ?? '',
              img: product?.img ?? '',
              camera: product?.camera ?? '',
              storage: product?.description ?? '',
              name: product?.name ?? '',
              price: product?.price ?? '',
            },
          ],
        })
      ),
      map((ref) => ref.id)
    );
  }

  getmybooking(): Observable<cart[]> {
    const ref = collection(this.firestore, 'cart');
    return this.auth.currentUser$.pipe(
      concatMap((user) => {
        const MuQuery = query(
          ref,
          where('UserIDS', 'array-contains', user?.uid)
        );
        return collectionData(MuQuery, { idField: 'id' }) as Observable<cart[]>
      })
    )
  }

  RemoveFromBooking(id: any) {

    return this.cartproduct.doc(id).delete()
  }
}

