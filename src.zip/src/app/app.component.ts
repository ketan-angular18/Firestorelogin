import { Component } from '@angular/core';
import { AuthenticationService } from './services/auth.service';
import { Router } from '@angular/router';
import { UserService } from './services/user/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firestorelogin2';
  user$ = this.usersService.cureentUserProfile;
  constructor(public auth: AuthenticationService, private route: Router, private usersService: UserService) {
  }
  logout() {
    this.auth.logout().subscribe(() => {
      this.route.navigate(['\login'])
    })
  }
}
