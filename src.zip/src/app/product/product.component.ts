import { Component } from '@angular/core';
import { map } from 'rxjs';
import { ProductsService } from '../services/product/products.service';
import { product } from '../_helper/product-details';
import { cart } from '../_helper/product-details';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  products: product[]
  mycart: any = []
  constructor(private product: ProductsService, private snackbar: MatSnackBar) {
    this.products = []
  }
  ngOnInit(): void {
    this.getallproduct()
    this.getcart()
  }
  getallproduct() {
    this.product.getAll().snapshotChanges().pipe(
      map(changes =>
        changes.map(c =>
          ({ id: c.payload.doc.id, ...c.payload.doc.data() })
        )
      )
    )
      .subscribe(data => {
        this.products = data
      })
  }

  addtocart(mobile: cart) {
    this.product.createbook(mobile).subscribe((data) => {
      this.snackbar.open("Product Added to cart", 'Added', {
        duration: 2000,
        panelClass: ['blue']
      });
    })
  }
  getcart() {
    this.product.getmybooking().subscribe((res) => {
      this.mycart = res
    })
  }
}
