import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { passwordsMatchValidator } from '../_helper/customvalidator';
import { AuthenticationService } from '../services/auth.service';
import { Router } from '@angular/router';

import { UserService } from '../services/user/user.service';
import { switchMap } from 'rxjs';
import { Location } from '@angular/common';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {

  signUpForm = new FormGroup(
    {
      name: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.email, Validators.required]),
      password: new FormControl('', Validators.required),
      confirmPassword: new FormControl('', Validators.required),
    },
    {
      validators: passwordsMatchValidator(),
    }
  );
  constructor(private auth: AuthenticationService,
    private route: Router,

    private user: UserService,
    private locatin: Location
  ) { }

  get name() {
    return this.signUpForm.get('name');
  }
  get email() {
    return this.signUpForm.get('email');
  }
  get password() {
    return this.signUpForm.get('password');
  }
  get confirmPassword() {
    return this.signUpForm.get('confirmPassword');
  }

  submit() {
    if (!this.signUpForm.valid) return;
    const { name, email, password } = this.signUpForm.value
    this.auth.Singup(email, password)
      .pipe(
        switchMap(({ user: { uid } }) =>
          this.user.adduser({ uid, email, displayName: name })))
      .subscribe(() => {
        this.route.navigate(['/home'])
      })
  }

  back() {
    this.locatin.back()
  }
}
