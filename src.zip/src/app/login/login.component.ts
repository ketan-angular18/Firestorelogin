import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginform = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', Validators.required)
  });

  get email() {
    return this.loginform.get('email')
  }
  get password() {
    return this.loginform.get('password')
  }
  constructor(private auth: AuthenticationService, private route: Router) {
  }
  Submit() {
    if (this.loginform.invalid) {
      return
    }
    const { email, password } = this.loginform.value
    this.auth.login(email, password).pipe(
    )
      .subscribe(() => {
        this.route.navigate(['home'])
      })
  }
}
