export interface ProfileUser {
    address?: string;
    displayName?: any;
    email?: any;
    firstName?: string;
    lastName?: string;
    phone?: string;
    photoURL?: string;
    uid: string;
  }