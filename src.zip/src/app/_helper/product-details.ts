export interface product{
    camera:string
    description:string
    name:string
    storage:string
    img:string
    price:string
    id?:string
   
}

export  interface cart{
    camera:string
    description:string
    name:string
    storage:string
    img:string
    price:string
    id?:string
}

