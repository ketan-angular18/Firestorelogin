import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { concatMap } from 'rxjs';
import { ProfileUser } from 'src/app/_helper/user-profile';
import { ImageuploadService } from 'src/app/_shared/imageupload.service';
import { UserService } from '../services/user/user.service';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Location } from '@angular/common';
@UntilDestroy()
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  user$ = this.usersService.cureentUserProfile;
  profileForm = new FormGroup({
    uid: new FormControl(''),
    displayName: new FormControl(''),
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    phone: new FormControl(''),
    address: new FormControl(''),
  });
  constructor(
    private usersService: UserService,
    private imageuploadservice: ImageuploadService,
    private router: Router,
    private location: Location
  ) { }
  ngOnInit(): void {
    this.usersService.cureentUserProfile
      .pipe(untilDestroyed(this))
      .subscribe((user) => {
        this.profileForm.patchValue({ ...user });
      });

     
  }
  saveProfile() {
    const profiledata: any = this.profileForm.value;
    this.usersService.updateUser(profiledata)
      
      .subscribe();
    this.router.navigate(['/home'])
  }
  uploadImage(event: any, user: ProfileUser) {
    this.imageuploadservice
      .uploadImage(event.target.files[0], `images/profile/${user.uid}`)
      .pipe(
               concatMap((photoURL) =>
          this.usersService.updateUser({ uid: user.uid, photoURL }))
      ).subscribe();
  }
  goback() {
    this.location.back()
  }
}


