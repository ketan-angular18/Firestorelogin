import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { ProductsService } from '../services/product/products.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {

  mycart: any = [];
  pricearray: any = []
  sum: number = 0;
  text: number = 0;
  totalprise: number = 0;
  grandtotal: number = 0;

  paymentRequest = {
    apiVersion: 2,
    apiVersionMinor: 0,
    allowedPaymentMethods: [
      {
        type: "CARD",
        parameters: {
          allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
          allowedCardNetworks: ["AMEX", "VISA", "MASTERCARD"]
        },
        tokenizationSpecification: {
          type: "PAYMENT_GATEWAY",
          parameters: {
            gateway: "example",
            gatewayMerchantId: "exampleGatewayMerchantId"
          }
        }
      }
    ],
    merchantInfo: {
      merchantId: "ketan",
      merchantName: "Demo Merchant"
    },
    transactionInfo: {
      totalPriceStatus: "FINAL",
      totalPriceLabel: "Total",
      totalPrice: "100.00",
      currencyCode: "USD",
      countryCode: "US"
    }
  };

  constructor(private location: Location, private product: ProductsService, private snack: MatSnackBar) {
  }

  ngOnInit(): void {
    this.getmybook()
    this.gettotal()
    this.filterarra()
  }

  back() {
    this.location.back()
  }

  getmybook() {
    this.product.getmybooking().subscribe((res) => {
      console.log(res)
      this.mycart = res
    })
  }

  Removemobile(id: any) {
    if (confirm('Are you sure to cancel this Booking')) {
      this.product.RemoveFromBooking(id).then(() => {
        this.snack.open('Prduct Removed', 'Deleted', {
          duration: 3000,
        });
      })
    }
  }

  gettotal() {
    this.product.getmybooking().subscribe((data) => {
      this.mycart = data
      for (let i = 0; i < this.mycart.length; i++) {
        let num = +this.mycart[i].AddToBook[0].price
        this.sum += num
        this.totalprise = this.sum
      }
      this.sum = 0
      this.text = this.totalprise * 18 / 100
      this.grandtotal = this.totalprise + this.text
    })
  }

  onLoadPaymentData(event: any) {
    console.log("load payment data", event.detail);
  }

  filterarra(){
    this.product.getmybooking().subscribe((data)=>{
      console.log(data)
      const dataas=data.find(item=>item.id==item.id)
      console.log(dataas)
      })
  }

}

