import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { canActivate, redirectLoggedInTo, redirectUnauthorizedTo } from '@angular/fire/auth-guard';
import { ProfileComponent } from './profile/profile.component';
import { ProductComponent } from './product/product.component';
import { CartComponent } from './cart/cart.component';
import { NotfoundComponent } from './notfound/notfound.component';

const redirecttologin = () => redirectUnauthorizedTo(['login']);
const redirecttohome = () => redirectLoggedInTo(['home']);

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: LoginComponent,
    ...canActivate(redirecttohome)
  },
  {
    path: 'login',
    component: LoginComponent,
    ...canActivate(redirecttohome)

  },
  {
    path: 'signup',
    component: SignupComponent,
    ...canActivate(redirecttohome)
  },
  {
    path: 'home',
    component: HomeComponent,
    ...canActivate(redirecttologin)
  },
  {
    path: 'profile',
    component: ProfileComponent,
    ...canActivate(redirecttologin)
  },
  {
    path: 'product',
    component: ProductComponent,
    ...canActivate(redirecttologin)
  },
  {
    path: 'cart',
    component: CartComponent,
    ...canActivate(redirecttologin)
  },
  {
    path:'**',
    pathMatch:'full',
    component:NotfoundComponent
    
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
