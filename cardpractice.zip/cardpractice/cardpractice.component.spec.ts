import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardpracticeComponent } from './cardpractice.component';

describe('CardpracticeComponent', () => {
  let component: CardpracticeComponent;
  let fixture: ComponentFixture<CardpracticeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CardpracticeComponent]
    });
    fixture = TestBed.createComponent(CardpracticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
