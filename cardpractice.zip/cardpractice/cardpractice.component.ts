import { Component } from '@angular/core';

@Component({
  selector: 'app-cardpractice',
  templateUrl: './cardpractice.component.html',
  styleUrls: ['./cardpractice.component.css']
})
export class CardpracticeComponent {

}
